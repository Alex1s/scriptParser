CREATETIME="2015-12-05 20:24:24";

adaptResolution(768, 1024);
adaptOrientation(ORIENTATION_TYPE.LANDSCAPE_LEFT);

touchDown(1, 48, 396);
usleep(49554.17);
touchUp(1, 47, 399);
usleep(1947723.38);

touchDown(7, 603, 274);
usleep(66292.83);
touchUp(7, 604, 274);
usleep(1215991.08);

touchDown(7, 622, 289);
usleep(66608.21);
touchUp(7, 622, 290);
usleep(7280184.67);

touchDown(5, 47, 906);
usleep(10366.46);
touchMove(5, 46, 897);
usleep(16754.83);
touchMove(5, 46, 880);
usleep(16721.42);
touchMove(5, 46, 857);
usleep(16541.00);
touchMove(5, 47, 825);
usleep(16507.75);
touchMove(5, 55, 790);
usleep(16585.75);
touchUp(5, 57, 788);
usleep(1345897.04);

touchDown(8, 44, 975);
usleep(33179.42);
touchUp(8, 42, 975);
usleep(1797317.17);

touchDown(2, 395, 478);
usleep(66873.75);
touchUp(2, 395, 479);
usleep(933825.88);

touchDown(11, 449, 552);
usleep(49668.38);
touchUp(11, 448, 553);
usleep(1046383.58);

touchDown(3, 507, 622);
usleep(66483.71);
touchUp(3, 508, 623);
usleep(1964060.08);

touchDown(10, 41, 482);
usleep(16555.21);
touchMove(10, 41, 488);
usleep(16806.46);
touchMove(10, 41, 506);
usleep(16279.92);
touchMove(10, 42, 536);
usleep(16742.17);
touchMove(10, 42, 577);
usleep(16945.54);
touchMove(10, 42, 624);
usleep(16206.54);
touchMove(10, 38, 674);
usleep(16407.04);
touchUp(10, 36, 676);
usleep(2166352.62);

touchDown(6, 37, 740);
usleep(43557.50);
touchUp(6, 35, 740);
usleep(1747890.62);

touchDown(4, 498, 186);
usleep(66532.21);
touchUp(4, 498, 184);
usleep(984070.54);

touchDown(9, 56, 312);
usleep(66446.88);
touchUp(9, 56, 312);
usleep(1980550.83);

touchDown(1, 415, 114);
usleep(66598.33);
touchUp(1, 417, 117);
usleep(365180.79);

touchDown(1, 418, 112);
usleep(49656.12);
touchUp(1, 418, 114);
usleep(382413.17);

touchDown(1, 409, 108);
usleep(66029.79);
touchUp(1, 409, 110);
usleep(349062.50);

touchDown(1, 415, 112);
usleep(49563.96);
touchUp(1, 416, 114);
usleep(10428163.79);

touchDown(7, 45, 150);
usleep(60173.71);
touchUp(7, 46, 150);
usleep(17083950.04);

touchDown(5, 291, 224);
usleep(76807.54);
touchUp(5, 292, 225);
usleep(133559.00);

touchDown(5, 295, 227);
usleep(53458.75);
touchUp(5, 295, 229);
usleep(99821.12);

touchDown(5, 295, 225);
usleep(49678.21);
touchUp(5, 295, 226);
usleep(8396061.75);

touchDown(8, 65, 72);
usleep(60166.04);
touchUp(8, 66, 73);
usleep(735309.50);

touchDown(2, 209, 333);
usleep(66140.17);
touchUp(2, 206, 337);
usleep(99670.42);

touchDown(2, 194, 357);
usleep(49584.29);
touchUp(2, 194, 361);
usleep(2101133.38);

touchDown(11, 56, 805);
usleep(59995.62);
touchUp(11, 56, 806);
usleep(5947248.54);

touchDown(3, 338, 346);
usleep(65982.92);
touchUp(3, 336, 347);
usleep(9182704.50);

touchDown(6, 61, 742);
usleep(76621.50);
touchUp(6, 60, 745);
usleep(4166761.04);

touchDown(10, 57, 897);
usleep(60070.38);
touchUp(10, 56, 900);
usleep(1482688.88);

touchDown(4, 349, 426);
usleep(49635.21);
touchUp(4, 349, 427);
usleep(6592622.92);

touchDown(9, 57, 975);
usleep(43617.04);
touchUp(9, 56, 976);
usleep(896894.04);

touchDown(4, 347, 398);
usleep(49799.54);
touchUp(4, 348, 402);
