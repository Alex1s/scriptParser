CREATETIME="2015-12-05 20:19:14";

adaptResolution(768, 1024);
adaptOrientation(ORIENTATION_TYPE.LANDSCAPE_LEFT);

touchDown(6, 53, 422);
usleep(26886.54);
touchUp(6, 52, 424);
usleep(2948065.21);

touchDown(5, 224, 738);
usleep(66409.62);
touchUp(5, 223, 737);
usleep(99444.96);

touchDown(5, 224, 741);
usleep(49999.33);
touchUp(5, 224, 740);
usleep(1270768.71);

touchDown(10, 63, 749);
usleep(49629.33);
touchUp(10, 63, 749);
usleep(3773330.62);

touchDown(7, 365, 882);
usleep(60414.79);
touchUp(7, 365, 882);
usleep(282154.42);

touchDown(2, 57, 303);
usleep(66666.54);
touchUp(2, 57, 302);
usleep(5981615.88);

touchDown(3, 404, 885);
usleep(82129.46);
touchUp(3, 404, 886);
usleep(99782.75);

touchDown(3, 406, 888);
usleep(82607.29);
touchUp(3, 406, 888);
usleep(116655.00);

touchDown(3, 402, 887);
usleep(66252.83);
touchUp(3, 403, 887);
usleep(100133.38);

touchDown(3, 401, 888);
usleep(32724.12);
touchUp(3, 401, 889);
usleep(23513263.58);

touchDown(10, 59, 750);
usleep(43652.08);
touchUp(10, 61, 748);
usleep(3412946.75);

touchDown(9, 68, 147);
usleep(43633.79);
touchUp(9, 66, 152);
usleep(739464.71);

touchDown(8, 299, 823);
usleep(82785.21);
touchUp(8, 299, 824);
usleep(66765.38);

touchDown(8, 305, 825);
usleep(49739.38);
touchUp(8, 305, 825);
usleep(2199290.88);

touchDown(11, 47, 826);
usleep(60211.88);
touchUp(11, 45, 828);
usleep(5628717.50);

touchDown(4, 332, 713);
usleep(25546.21);
touchUp(4, 332, 713);
usleep(465359.54);

touchDown(1, 63, 900);
usleep(66606.71);
touchUp(1, 62, 899);
usleep(564616.54);

touchDown(6, 355, 595);
usleep(66324.38);
touchUp(6, 355, 594);
usleep(3347392.00);

touchDown(9, 73, 162);
usleep(43714.08);
touchUp(9, 73, 163);
usleep(747697.50);

touchDown(8, 289, 802);
usleep(66066.50);
touchUp(8, 289, 804);
usleep(3904500.92);

touchDown(1, 62, 892);
usleep(26790.71);
touchUp(1, 61, 893);
usleep(1083028.17);

touchDown(5, 359, 561);
usleep(38254.04);
touchUp(5, 360, 562);
