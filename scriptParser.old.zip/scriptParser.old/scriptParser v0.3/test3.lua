CREATETIME="2015-12-06 18:31:59";

adaptResolution(1536, 2048);
adaptOrientation(ORIENTATION_TYPE.LANDSCAPE_LEFT);

touchDown(4, 120, 1678);
usleep(20000);
touchUp(4, 127, 1672);
usleep(20000);

touchDown(3, 840, 1034);
usleep(20000);
touchUp(3, 840, 1035);
usleep(20000);

touchDown(3, 840, 1022);
usleep(20000);
touchUp(3, 840, 1023);
usleep(20000);

touchDown(3, 830, 1022);
usleep(20000);
touchUp(3, 830, 1024);
usleep(20000);

touchDown(3, 830, 1024);
usleep(20000);
touchUp(3, 830, 1019);
usleep(20000);

touchDown(2, 152, 1816);
usleep(20000);
touchUp(2, 157, 1810);
usleep(20000);

touchDown(3, 837, 1024);
usleep(20000);
touchUp(3, 837, 1025);
usleep(20000);

touchDown(3, 833, 1021);
usleep(20000);
touchUp(3, 793, 1025);

-- Lure

usleep(100000);


touchDown(5, 150, 757);
usleep(83365.12);
touchUp(5, 156, 763);
usleep(666811.25);

touchDown(9, 988, 1774);
usleep(116666.04);
touchUp(9, 984, 1774);
usleep(433544.08);

touchDown(11, 158, 1523);
usleep(100044.42);
touchUp(11, 164, 1520);
usleep(533445.67);

touchDown(9, 1007, 1793);
usleep(149659.67);
touchUp(9, 1001, 1800);
usleep(266902.21);

touchDown(7, 140, 604);
usleep(66921.17);
touchUp(7, 140, 603);
usleep(416266.17);

touchDown(4, 681, 1730);
usleep(116517.75);
touchUp(4, 683, 1726);
usleep(450321.12);

touchDown(5, 139, 777);
usleep(83149.62);
touchUp(5, 138, 783);
usleep(1366912.67);

touchDown(1, 1161, 1486);
usleep(199926.67);
touchUp(1, 1163, 1489);
usleep(1233378.17);

touchDown(7, 157, 617);
usleep(66993.58);
touchUp(7, 156, 617);
usleep(916924.62);

touchDown(3, 1319, 1276);
usleep(99896.67);
touchUp(3, 1323, 1292);
usleep(650049.58);

touchDown(2, 181, 423);
usleep(66510.75);
touchUp(2, 187, 424);
usleep(349902.54);

touchDown(6, 1217, 1420);
usleep(66679.71);
touchUp(6, 1221, 1418);
usleep(983396.25);

touchDown(8, 195, 97);
usleep(100034.83);
touchUp(8, 192, 100);
usleep(1283714.00);

touchDown(1, 1154, 1524);
usleep(100098.46);
touchUp(1, 1158, 1531);
usleep(99849.50);

touchDown(1, 1155, 1521);
usleep(83220.29);
touchUp(1, 1156, 1522);
usleep(66816.67);

touchDown(1, 1155, 1520);
usleep(66296.04);
touchUp(1, 1155, 1522);
usleep(14718450.25);

touchDown(1, 1179, 1526);
usleep(833016.50);
touchUp(1, 1189, 1539);
usleep(1900222.00);

touchDown(10, 155, 1340);
usleep(66918.50);
touchUp(10, 173, 1339);
usleep(583260.50);

touchDown(1, 1157, 1542);
usleep(83158.75);
touchUp(1, 1155, 1544);
--usleep(15001371.62);
usleep(14000000);

touchDown(10, 161, 1340);
usleep(66430.71);
touchUp(10, 163, 1338);
--usleep(1500499.04);
usleep(500000);

touchDown(11, 131, 1500);
usleep(66402.33);
touchUp(11, 133, 1500);

-- flight

usleep(6000000);

touchDown(3, 195, 260);
usleep(20000);
touchUp(3, 193, 265);
usleep(20000);

touchDown(2, 1452, 1195);
usleep(20000);
touchUp(2, 1451, 1193);
usleep(20000);

touchDown(2, 1448, 1191);
usleep(20000);
touchUp(2, 1446, 1190);
usleep(20000);

touchDown(2, 1447, 1186);
usleep(20000);
touchUp(2, 1446, 1188);
usleep(20000);

touchDown(4, 1310, 1322);
usleep(20000);
touchUp(4, 1311, 1318);
usleep(20000);

touchDown(4, 1312, 1320);
usleep(20000);
touchUp(4, 1314, 1318);
usleep(20000);

touchDown(4, 1311, 1316);
usleep(20000);
touchUp(4, 1306, 1313);
usleep(6000000);

touchDown(8, 173, 937);
usleep(20000);
touchUp(8, 177, 935);
usleep(20000);

touchDown(2, 1399, 1183);
usleep(20000);
touchUp(2, 1401, 1181);
usleep(1000000);

touchDown(1, 1228, 511);
usleep(20000);
touchUp(1, 1222, 517);
usleep(20000);

touchDown(3, 155, 280);
usleep(20000);
touchUp(3, 171, 290);
usleep(20000);

touchDown(1, 1244, 510);
usleep(20000);
touchUp(1, 1248, 516);
usleep(20000);

touchDown(1, 1246, 515);
usleep(20000);
touchUp(1, 1247, 518);
usleep(20000);

touchDown(1, 1245, 515);
usleep(20000);
touchUp(1, 1248, 523);
usleep(20000);

touchDown(1, 1243, 519);
usleep(20000);
touchUp(1, 1241, 519);
usleep(20000);

touchDown(11, 170, 1198);
usleep(20000);
touchUp(11, 181, 1197);
usleep(500000);

touchDown(9, 1022, 356);
usleep(20000);
touchUp(9, 1015, 348);
usleep(900000);

touchDown(3, 141, 239);
usleep(20000);
touchUp(3, 154, 255);
usleep(1000000);

touchDown(6, 1069, 417);
usleep(20000);
touchUp(6, 1066, 416);
usleep(20000);

touchDown(6, 1068, 420);
usleep(20000);
touchUp(6, 1067, 419);
usleep(20000);

touchDown(6, 1065, 417);
usleep(20000);
touchUp(6, 1058, 412);
usleep(500000);

touchDown(5, 920, 256);
usleep(20000);
touchUp(5, 925, 269);
usleep(20000);

touchDown(5, 922, 280);
usleep(20000);
touchUp(5, 919, 287);
usleep(20000);

touchDown(5, 921, 292);
usleep(20000);
touchUp(5, 914, 294);
usleep(20000);

touchDown(5, 914, 295);
usleep(20000);
touchUp(5, 910, 299);
usleep(20000);

touchDown(10, 135, 1976);
usleep(20000);
touchUp(10, 135, 1973);
usleep(7500000);

touchDown(7, 878, 691);
usleep(20000);
touchUp(7, 881, 692);
usleep(5252325.75);

touchDown(3, 153, 271);
usleep(20000);
touchUp(3, 162, 286);
usleep(3333649.17);

touchDown(4, 482, 559);
usleep(20000);
touchMove(4, 488, 563);
usleep(20000);
touchUp(4, 487, 562);

usleep(20000000);

touchDown(5, 125, 258);
usleep(20000);
touchUp(5, 128, 265);
usleep(50000);

--[[touchDown(1, 428, 1467);
usleep(30000);
touchUp(1, 429, 1468);
usleep(30000);

touchDown(1, 428, 1463);
usleep(30000);
touchUp(1, 430, 1467);
]]

touchDown(9, 338, 723);
usleep(83156.29);
touchUp(9, 342, 722);
usleep(66905.79);

touchDown(9, 342, 722);
usleep(99761.33);
touchUp(9, 344, 723);
