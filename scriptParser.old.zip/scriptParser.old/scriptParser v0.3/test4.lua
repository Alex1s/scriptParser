CREATETIME="2015-12-07 16:43:45";

adaptResolution(768, 1024);
adaptOrientation(ORIENTATION_TYPE.LANDSCAPE_LEFT);

touchDown(10, 59, 810);
usleep(66561.04);
touchUp(10, 59, 811);
usleep(1687076.29);

touchDown(3, 457, 118);
usleep(82555.12);
touchUp(3, 457, 120);
usleep(1064143.00);

touchDown(9, 50, 388);
usleep(65994.17);
touchUp(9, 48, 398);
usleep(773337.12);

touchDown(2, 538, 153);
usleep(82658.54);
touchUp(2, 538, 153);
usleep(232722.71);

touchDown(2, 540, 148);
usleep(83301.71);
touchUp(2, 543, 149);
usleep(165949.83);

touchDown(2, 543, 145);
usleep(66597.50);
touchUp(2, 545, 145);
usleep(99582.71);

touchDown(2, 549, 143);
usleep(66647.33);
touchUp(2, 549, 143);
usleep(798107.83);

touchDown(11, 48, 301);
usleep(32811.71);
touchUp(11, 46, 303);
usleep(1570669.67);

touchDown(5, 350, 126);
usleep(99719.29);
touchUp(5, 352, 126);
usleep(116299.29);

touchDown(5, 351, 122);
usleep(66500.17);
touchUp(5, 351, 124);
usleep(4786698.38);

touchDown(4, 49, 226);
usleep(27169.38);
touchUp(4, 47, 231);
usleep(4019652.79);

touchDown(2, 551, 166);
usleep(76904.46);
touchUp(2, 553, 163);
usleep(99682.62);

touchDown(2, 554, 164);
usleep(83033.00);
touchUp(2, 553, 163);
usleep(66527.29);

touchDown(2, 553, 163);
usleep(66613.46);
touchUp(2, 553, 164);
usleep(16102930.38);

touchDown(6, 52, 926);
usleep(43602.17);
touchMove(6, 50, 916);
usleep(16636.21);
touchMove(6, 50, 900);
usleep(16546.92);
touchMove(6, 48, 875);
usleep(16895.33);
touchMove(6, 45, 837);
usleep(16262.21);
touchMove(6, 45, 796);
usleep(16663.62);
touchMove(6, 45, 761);
usleep(16840.04);
touchMove(6, 49, 729);
usleep(16405.29);
touchMove(6, 66, 682);
usleep(16378.67);
touchUp(6, 68, 680);
usleep(1213777.33);

touchDown(1, 55, 891);
usleep(49714.67);
touchUp(1, 57, 894);
usleep(3060775.12);

touchDown(7, 497, 306);
usleep(59905.42);
touchUp(7, 498, 307);
usleep(29763871.71);

touchDown(10, 61, 803);
usleep(50117.75);
touchUp(10, 62, 806);
usleep(4753925.42);

touchDown(4, 52, 214);
usleep(26987.29);
touchUp(4, 57, 218);
usleep(731559.58);

touchDown(8, 681, 396);
usleep(83003.50);
touchUp(8, 684, 397);
usleep(102597.96);

touchDown(8, 687, 394);
usleep(55426.12);
touchUp(8, 686, 395);
usleep(49904.12);

touchDown(8, 684, 392);
usleep(49949.38);
touchUp(8, 686, 396);
usleep(5261001.50);
touchUp(3, 662, 328);
usleep(149569.08);

touchDown(3, 671, 336);
usleep(83280.33);
touchUp(3, 671, 338);
usleep(83366.08);

touchDown(3, 673, 339);
usleep(16421.46);
touchUp(3, 676, 340);
usleep(5042748.79);

touchDown(8, 684, 407);
usleep(59994.29);
touchUp(8, 684, 407);
usleep(83512.79);

touchDown(8, 690, 402);
usleep(49750.08);
touchUp(8, 690, 404);
usleep(6928707.75);

touchDown(9, 56, 437);
usleep(11388.67);
touchMove(9, 58, 452);
usleep(15755.29);
touchMove(9, 58, 489);
usleep(16599.92);
touchMove(9, 56, 543);
usleep(16888.42);
touchMove(9, 45, 601);
usleep(16368.71);
touchMove(9, 35, 656);
usleep(16502.04);
touchMove(9, 25, 707);
usleep(16687.79);
touchUp(9, 23, 709);
usleep(1354638.54);

touchDown(11, 53, 145);
usleep(33530.83);
touchUp(11, 55, 148);
