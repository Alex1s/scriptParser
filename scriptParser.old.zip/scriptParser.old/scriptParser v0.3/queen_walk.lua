CREATETIME="2015-12-05 13:59:40";

adaptResolution(768, 1024);
adaptOrientation(ORIENTATION_TYPE.LANDSCAPE_LEFT);

touchDown(7, 37, 419);
usleep(49690.38);
touchUp(7, 37, 420);
usleep(2954957.33);

touchDown(9, 203, 290);
usleep(110023.38);
touchUp(9, 203, 289);
usleep(115820.33);

touchDown(9, 205, 289);
usleep(66914.83);
touchUp(9, 204, 289);
usleep(2527662.42);

touchDown(10, 54, 723);
usleep(43586.71);
touchUp(10, 52, 725);
usleep(4004281.00);

touchDown(11, 304, 190);
usleep(93245.33);
touchUp(11, 304, 188);
usleep(485991.00);

touchDown(2, 60, 310);
usleep(49932.42);
touchUp(2, 59, 311);
usleep(714402.88);

touchDown(3, 361, 108);
usleep(83076.33);
touchUp(3, 363, 110);
usleep(249243.42);

touchDown(3, 365, 112);
usleep(33399.42);
touchUp(3, 366, 115);
usleep(365379.71);

touchDown(3, 366, 109);
usleep(66247.83);
touchUp(3, 367, 110);
usleep(203677.42);

touchDown(3, 364, 107);
usleep(66621.38);
touchUp(3, 366, 107);
usleep(32474528.46);

touchDown(1, 43, 231);
usleep(60012.79);
touchUp(1, 44, 233);
usleep(5545873.21);

touchDown(5, 702, 645);
usleep(77023.25);
touchUp(5, 699, 647);
usleep(133086.50);

touchDown(5, 696, 643);
usleep(66501.33);
touchUp(5, 695, 645);
usleep(149616.83);

touchDown(5, 693, 643);
usleep(65837.62);
touchUp(5, 693, 645);
usleep(631477.54);

touchDown(5, 691, 642);
usleep(681237.04);
touchUp(5, 689, 644);
usleep(1831601.38);

touchDown(4, 53, 135);
usleep(49743.92);
touchUp(4, 54, 137);
usleep(834905.79);

touchDown(6, 523, 208);
usleep(99729.92);
touchUp(6, 522, 211);
usleep(83171.58);

touchDown(6, 518, 206);
usleep(66283.25);
touchUp(6, 519, 205);
usleep(66404.46);

touchDown(6, 516, 209);
usleep(33141.96);
touchUp(6, 517, 209);
usleep(15199663.33);

touchDown(6, 545, 209);
usleep(1361848.54);
touchUp(6, 547, 209);
usleep(403086.92);

touchDown(8, 65, 825);
usleep(66340.29);
touchUp(8, 67, 824);
usleep(1628236.88);

touchDown(7, 478, 356);
usleep(70399.62);
touchUp(7, 477, 359);
usleep(13122325.38);

touchDown(10, 64, 736);
usleep(60518.38);
touchUp(10, 64, 738);
