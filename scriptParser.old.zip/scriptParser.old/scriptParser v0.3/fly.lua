CREATETIME="2015-12-12 14:06:51";

adaptResolution(768, 1024);
adaptOrientation(ORIENTATION_TYPE.LANDSCAPE_RIGHT);

touchDown(8, 50, 843);
usleep(16441.50);
touchMove(8, 55, 810);
usleep(16729.04);
touchMove(8, 67, 760);
usleep(16851.00);
touchMove(8, 90, 678);
usleep(16452.96);
touchMove(8, 115, 570);
usleep(16470.96);
touchMove(8, 115, 451);
usleep(16620.21);
touchUp(8, 115, 449);