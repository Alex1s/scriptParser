CREATETIME="2015-12-12 03:51:26";

adaptResolution(768, 1024);
adaptOrientation(ORIENTATION_TYPE.LANDSCAPE_LEFT);

touchDown(5, 47, 478);
usleep(82526.29);
touchUp(5, 48, 484);
usleep(879683.46);

touchDown(11, 706, 490);
usleep(66524.62);
touchUp(11, 710, 495);
usleep(738755.12);

touchDown(4, 662, 708);
usleep(82681.08);
touchUp(4, 663, 705);
usleep(846593.17);

touchDown(2, 63, 822);
usleep(65897.67);
touchUp(2, 57, 820);
usleep(1103980.50);

touchDown(7, 470, 206);
usleep(49647.46);
touchUp(7, 470, 207);
usleep(1062592.79);

touchDown(1, 72, 411);
usleep(65924.75);
touchUp(1, 74, 411);
usleep(755210.38);

touchDown(6, 375, 219);
usleep(116467.92);
touchUp(6, 378, 222);
usleep(99549.38);

touchDown(6, 376, 221);
usleep(99531.21);
touchUp(6, 376, 222);
usleep(99490.21);

touchDown(6, 376, 223);
usleep(82891.96);
touchUp(6, 376, 223);
usleep(116483.29);

touchDown(6, 378, 224);
usleep(66130.79);
touchUp(6, 378, 225);
usleep(66270.42);

touchDown(6, 380, 225);
usleep(49977.21);
touchUp(6, 381, 229);
usleep(53631237.62);

touchDown(8, 50, 315);
usleep(43738.75);
touchUp(8, 46, 317);
usleep(4879311.62);

touchDown(3, 199, 577);
usleep(76695.46);
touchUp(3, 199, 577);
usleep(755446.29);

touchDown(10, 70, 156);
usleep(49765.08);
touchUp(10, 75, 164);
usleep(863130.67);

touchDown(9, 270, 409);
usleep(99385.04);
touchUp(9, 270, 412);
usleep(82815.79);

touchDown(9, 269, 415);
usleep(66666.50);
touchUp(9, 272, 415);
usleep(66365.25);

touchDown(9, 277, 417);
usleep(82862.46);
touchUp(9, 277, 418);
usleep(9259435.25);

touchDown(5, 67, 909);
usleep(60054.04);
touchUp(5, 69, 916);
usleep(11077536.88);

touchDown(11, 315, 489);
usleep(116329.75);
touchUp(11, 315, 490);
usleep(1252790.75);

touchDown(4, 55, 987);
usleep(66516.92);
touchUp(4, 59, 987);
usleep(1817150.42);

touchDown(2, 392, 522);
usleep(66250.58);
touchUp(2, 393, 523);
usleep(3569357.29);

touchDown(10, 52, 153);
usleep(43850.58);
touchUp(10, 58, 160);
usleep(4208463.42);

touchDown(9, 252, 437);
usleep(93499.33);
touchUp(9, 252, 438);
usleep(2364628.67);

touchDown(7, 235, 464);
usleep(83056.33);
touchUp(7, 235, 466);
