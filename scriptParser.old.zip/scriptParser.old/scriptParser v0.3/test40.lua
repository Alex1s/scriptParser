CREATETIME="2015-12-09 22:46:31";

adaptResolution(768, 1024);

touchDown(4, 50, 818);
usleep(66270.88);
touchUp(4, 49, 822);
usleep(698054.96);

touchDown(11, 368, 929);
usleep(66354.04);
touchUp(11, 368, 930);
usleep(448854.33);

touchDown(2, 61, 384);
usleep(66573.00);
touchUp(2, 62, 384);
usleep(652261.79);

touchDown(8, 444, 960);
usleep(66436.21);
touchUp(8, 445, 957);
usleep(99646.33);

touchDown(8, 442, 960);
usleep(66518.29);
touchUp(8, 443, 960);
usleep(83193.79);

touchDown(8, 442, 962);
usleep(49476.92);
touchUp(8, 441, 962);
usleep(3380238.67);

touchDown(6, 56, 327);
usleep(43497.00);
touchUp(6, 54, 328);
usleep(1080264.33);

touchDown(1, 534, 857);
usleep(82846.79);
touchUp(1, 534, 859);
usleep(87699.83);

touchDown(1, 534, 855);
usleep(50140.29);
touchUp(1, 532, 851);
usleep(8557459.50);

touchDown(5, 50, 233);
usleep(60345.12);
touchUp(5, 48, 235);
usleep(1899368.71);

touchDown(9, 311, 796);
usleep(66268.96);
touchUp(9, 312, 798);
usleep(82799.29);

touchDown(9, 311, 802);
usleep(66029.25);
touchUp(9, 312, 802);
usleep(5636347.33);

touchDown(3, 45, 914);
usleep(10217.46);
touchMove(3, 54, 882);
usleep(15257.54);
touchMove(3, 67, 852);
usleep(16623.25);
touchMove(3, 78, 818);
usleep(16819.58);
touchMove(3, 81, 794);
usleep(16494.46);
touchMove(3, 81, 769);
usleep(16569.42);
touchMove(3, 80, 749);
usleep(16841.42);
touchUp(3, 78, 747);
usleep(1329383.88);

touchDown(7, 58, 987);
usleep(49608.08);
touchUp(7, 55, 988);
usleep(2453374.92);

touchDown(10, 530, 649);
usleep(43747.50);
touchUp(10, 528, 651);
usleep(535743.92);

touchDown(4, 521, 382);
usleep(49828.50);
touchUp(4, 520, 384);
usleep(1030674.75);

touchDown(11, 399, 279);
usleep(49324.83);
touchUp(11, 399, 280);
usleep(2662735.29);

touchDown(2, 72, 575);
usleep(10749.83);
touchMove(2, 72, 588);
usleep(15213.12);
touchMove(2, 72, 605);
usleep(16561.00);
touchMove(2, 72, 628);
usleep(16845.75);
touchMove(2, 72, 665);
usleep(16362.71);
touchMove(2, 70, 702);
usleep(16645.62);
touchMove(2, 68, 743);
usleep(17396.75);
touchMove(2, 68, 785);
usleep(15781.38);
touchMove(2, 68, 823);
usleep(16608.42);
touchUp(2, 69, 861);
usleep(1096909.08);

touchDown(8, 57, 894);
usleep(66707.21);
touchUp(8, 56, 896);
usleep(5425174.92);

touchDown(6, 336, 704);
usleep(76817.04);
touchUp(6, 334, 703);
usleep(3156292.12);

touchDown(3, 50, 751);
usleep(10450.96);
touchMove(3, 52, 744);
usleep(16665.67);
touchMove(3, 52, 732);
usleep(16785.83);
touchMove(3, 52, 716);
usleep(16455.25);
touchMove(3, 54, 696);
usleep(16609.83);
touchMove(3, 55, 673);
usleep(16840.17);
touchMove(3, 55, 658);
usleep(16135.83);
touchUp(3, 56, 656);
usleep(2229530.75);

touchDown(1, 44, 743);
usleep(27057.75);
touchUp(1, 44, 744);
usleep(5553437.25);

touchDown(5, 384, 584);
usleep(60606.21);
touchUp(5, 383, 585);
usleep(5585558.96);

touchDown(3, 45, 649);
usleep(76968.46);
touchUp(3, 44, 654);
usleep(1749546.33);

touchDown(9, 320, 629);
usleep(49714.42);
touchUp(9, 319, 630);
usleep(2676816.42);

touchDown(1, 48, 743);
usleep(76782.54);
touchUp(1, 48, 744);
usleep(685678.46);

touchDown(5, 398, 606);
usleep(49802.17);
touchUp(5, 398, 606);
usleep(10838226.38);

touchDown(5, 414, 616);
usleep(65858.83);
touchUp(5, 414, 618);
usleep(2709105.71);

touchDown(3, 42, 656);
usleep(76578.04);
touchUp(3, 46, 660);
usleep(482721.46);

touchDown(7, 317, 589);
usleep(32842.96);
touchUp(7, 315, 590);
usleep(13831376.08);

touchDown(10, 57, 398);
usleep(27233.92);
touchMove(10, 61, 413);
usleep(16706.79);
touchMove(10, 61, 425);
usleep(16461.92);
touchMove(10, 62, 440);
usleep(16687.67);
touchMove(10, 63, 462);
usleep(16764.12);
touchMove(10, 63, 485);
usleep(16413.92);
touchMove(10, 63, 511);
usleep(16686.08);
touchMove(10, 63, 537);
usleep(16720.33);
touchMove(10, 63, 563);
usleep(16545.67);
touchMove(10, 63, 587);
usleep(16543.50);
touchMove(10, 63, 614);
usleep(16632.54);
touchUp(10, 63, 616);
usleep(1030434.88);

touchDown(4, 48, 155);
usleep(66731.42);
touchUp(4, 52, 158);
usleep(802025.29);

touchDown(11, 282, 247);
usleep(66205.88);
touchUp(11, 280, 251);
usleep(1031127.04);

touchDown(2, 358, 161);
usleep(49481.88);
touchUp(2, 359, 161);
usleep(269919.92);

touchDown(8, 441, 131);
usleep(83270.04);
touchUp(8, 443, 134);
usleep(100025.38);

touchDown(6, 493, 172);
usleep(49635.29);
touchUp(6, 494, 173);
