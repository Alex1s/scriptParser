CREATETIME="2015-11-21 18:14:10";

adaptResolution(768, 1024);
adaptOrientation(ORIENTATION_TYPE.LANDSCAPE_RIGHT);

touchDown(9, 296, 413);
usleep(49699.75);
touchUp(9, 295, 413);
usleep(880305.71);

touchDown(9, 282, 397);
touchDown(10, 310, 536);
usleep(66298.79);
touchUp(9, 283, 402);
touchUp(10, 312, 538);
usleep(1300114.83);

touchDown(9, 296, 413);
usleep(49699.75);
touchMove(9, 320, 384)
touchUp(9, 322, 379);
usleep(880305.71);

touchDown(2, 313, 634);
touchDown(3, 257, 341);
touchDown(11, 349, 474);
usleep(49276.96);
touchUp(2, 311, 633);
touchUp(3, 253, 341);
touchUp(11, 344, 475);